#########################
# file sample extensions container #
#########################


Extensions for BT/RT assessment purposes.



A random collection of several extensions to help evaluate access control and execution policy into security solutions such as;



Proxies/Content Management

Antispam

Windows GPOs


Most of them are focused on Windows environment while others depends on its interpreters.


NOTES:


I don't own their copyrights. I didn't code anything. All of them were collected from the internet or in built-in operational system. I found dificult to hunt up a single source and download at once in order to test mimetype effectiveness and other access so now I have decided to publish and help others save time.
Some of the files may generate false posivites alerts when analyzed by antivirus or sandbox because I have invoked legit powershell commands (Get-Host).  E.g lnk,wsf. 

I recommend to consider controls always based on file true type AND extensions, because (true filetype) mimetype (generally identified by their magic number) may fail with scripts and extensions control may fail with routines which renames file at two-stage fails.   

Monitoring first;Blocking later. 

You shall consider your business beforing taking conclusions of blocking and mitigating.
There are business caracteristics that handles high risk files as macros, encrypted files, etc. It will be hard to change business requirements so you may consider exceptions under a governance better before than deciding to change your policies. 
Remember: Network visibility is a must.


Other helpful references: 

https://adsecurity.org/?p=3299 - Disable Windows Script Host (WSH) File Extensions (and others that execute code) 









      
